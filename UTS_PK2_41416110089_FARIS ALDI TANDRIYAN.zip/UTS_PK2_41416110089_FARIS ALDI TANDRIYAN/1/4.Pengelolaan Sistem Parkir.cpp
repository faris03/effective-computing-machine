#include <iostream>
#include <stdlib.h>

using namespace std;


main()

{

a:

 int jenis, pilih;

 long int harga;


 cout<<endl;

 cout<<"TEAM 1"<<endl;

 cout<<endl;

 cout<<"=>=>=>=>=>=>=>=>=>=>=> *We Are Informatics Engineering* <=<=<=<=<=<=<=<=<=<="<<endl;



 cout<<"--------------------------------------------------------------------------"<<endl;

 cout<<endl;

 cout<<endl;


 cout<<"                              Ticket Parking "<<endl;

 cout<<"                         ************************"<<endl;

 cout<<endl;

 cout<<endl;

 cout<<"::>::>::>::>::>::>::>::> Price Of The Type Of Vehicle <::<::<::<::<::<::<::<::"<<endl;

 cout<<"______________________________________________________________________________"<<endl;

 cout<<endl;

 cout<<"1. Car         = Rp 5000"<<endl;

 cout<<"2. Motorcycles = Rp 3000"<<endl;

 cout<<endl;


 cout<<"Select The Type Of Vehicle [1/2] = ";

 cin>>jenis;

 cout<<endl;

 switch (jenis)

 {

  case 1:

  cout<<"Your Vehicle Type Is    = Car"<<endl;

  harga = 5000;

  break;

  case 2:

  cout<<"Your Vehicle Type Is    = Motorcycles"<<endl;

  harga = 3000;

  break;

  default:

  cout<<"There Are Only Two Choice"<<endl;

  break;

 }

 if (jenis == 1)

 {

  int z, x=0, Q;

 int c=5000;

 cout<<"The Number Of Parking Hours =";

 cin>>Q;

 cout<<"1= 5000"<<endl;

 for(int y=2; y<=Q; y++)

 {

  int z=(y-y+3000);

  x = x + z;

  cout<<y<<"= ";

  cout<<z<<" "<<endl;

 }

 cout<<"* Amount To Be Paid = "<<x+c<<endl;

 cout<<endl;

 cout<<"* With Your Vehicle Type = car"<<endl;

 }

 else

 {

 int z, x=0, Q;

 int c=3000;

 cout<<"The Number Of Parking Hours =";

 cin>>Q;

 cout<<"1= 3000"<<endl;

 for(int y=2; y<=Q; y++)

 {

  int z=(y-y+2000);

  x = x + z;

  cout<<y<<"= ";

  cout<<z<<" "<<endl;

 }


 cout<<endl;

 cout<<"* Amount To Be Paid ="<<x+c<<endl;

 cout<<endl;

 cout<<"* With Your Vehicle Type = Motorcycles"<<endl;

 }

b:

 cout<<endl;

 cout<<endl;

 cout<<"         INFORMATION"<<endl;

 cout<<"================================"<<endl;

 cout<<"1. Back To Menu"<<endl;

 cout<<"2. Clear Screen"<<endl;

 cout<<"Your Choice [1/2]=";

 cin>>pilih;

 switch (pilih)

 {

 case 1:

  goto a;

 break;

 case 2:

  system ("cls");

 break;

 default:

  goto b;

 break;

 }


} 
