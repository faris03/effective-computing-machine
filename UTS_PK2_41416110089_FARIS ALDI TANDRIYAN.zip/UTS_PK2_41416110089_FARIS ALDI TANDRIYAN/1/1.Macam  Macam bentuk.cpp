#include <iostream>
using namespace std;
int main (){
cout <<"Faris Aldi Tandriyan"<<endl;
cout <<"NIM = "<<endl;
cout <<endl;
int i,j,x=5;
//membuat persegi tengahnya bolong
	 for(i=5;i>=1;i--){
            for(j=i;j>1;j--){
                if (i==x||j==i)
                    cout<<"*"<<" ";
                else
                    cout<<"  ";
            }
            for(j=1;j<=x-i+1;j++){
                if(i==1||j==x-i+1)
                    cout<<"*"<<" ";
                else
                    cout<<"  ";
            }
            cout<<endl;
        }
         cout<<endl;
	
//membuat persegi
	 for(i=5;i>=1;i--){
            for(j=i;j>1;j--){
                if (i==x||j==i)
                    cout<<"*"<<" ";
                else
                    cout<<"$ ";
            }
            for(j=1;j<=x-i+1;j++){
                if(i==1||j==x-i+1)
                    cout<<"*"<<" ";
                else
                    cout<<"$ ";
            }
            cout<<endl;
        }
         cout<<endl;
//membuat segitiga siku siku
for (i=1;i<=6;i++) {
		for (j=1;j<=i;j++) {
			cout <<"*";
		}
		cout << endl;
	}
   
    cout<<endl;
         
}

